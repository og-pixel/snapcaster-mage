package ac.uk.teamWorkbench

class ContextWindow: Window {

    override fun runFunction() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}