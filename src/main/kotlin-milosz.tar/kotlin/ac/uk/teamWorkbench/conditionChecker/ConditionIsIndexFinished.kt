package ac.uk.teamWorkbench.conditionChecker

import com.intellij.openapi.util.Condition
//import ac.uk.teamWorkbench.objectWorkbench.
//import java.util.function.Predicate


//class ConditionIsIndexFinished: Condition<> {
//    override fun test(p0: String): Boolean {
//        print(p0)
//        return true
//    }
//
//}