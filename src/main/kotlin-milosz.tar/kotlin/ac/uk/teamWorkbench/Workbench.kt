package ac.uk.teamWorkbench

class Workbench {

    fun createObject(){

    }

    fun inspectObject(){

    }

    fun deleteObject(){

    }

    fun listMethods(){

    }
}