package ac.uk.teamWorkbench

interface Window {
    fun runFunction()
}