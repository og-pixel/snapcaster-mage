package ac.uk.teamWorkbench

class InspectWindow: Window {

    val fields:List<String> = ArrayList()
    val methods:List<String> = ArrayList()
    val objects:List<String> = ArrayList()
    val inherited:List<String> = ArrayList()

    override fun runFunction() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

}